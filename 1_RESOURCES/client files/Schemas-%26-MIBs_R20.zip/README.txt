##############################################################################
#  Copyright � 2000-2012, BroadSoft, Inc.                                    #
#  This software and its documentation are protected by copyright law and    #
#  international treaties. Unauthorized reproduction or distribution of this #
#  software, or any part thereof, may result in severe civil and criminal    #
#  penalties, and will be prosecuted to the maximum extent possible          #
#  under the law.                                                            #
#  BroadWorks is a trademark of BroadSoft, Inc. Gaithersburg, MD             #
##############################################################################
Version=3
# ----------------------------------------------------------------- #
# Section: List of Documents (sorted by name)
# NOTE: The version column below specifies in which version of the
# archive this file was introduced.
# ----------------------------------------------------------------- #
Version   	Uploaded Date	Name
3         	11/04/13  	Rel20.0_XsiCTISchema_433939.zip
3         	11/21/13  	Rel20.0_XsiCTISchema_438273.zip
2         	02/19/14  	Rel20.0_XsiCTISchema_449493.zip
3         	07/30/14  	Rel_20.0_1.606_MIBs.zip
1         	11/20/13  	Rel_20.0_1.606_OCISchema_ALL.zip
1         	11/20/13  	Rel_20.0_1.606_OCISchema_AS_HTML.zip
1         	11/20/13  	Rel_20.0_1.606_OCISchema_NS_HTML.zip
# ----------------------------------------------------------------- #
# Section: List of Documents (sorted by date)
# NOTE: The version column below specifies in which version of the
# archive this file was introduced.
# ----------------------------------------------------------------- #
Version   	Uploaded Date	Name
3         	07/30/14  	Rel_20.0_1.606_MIBs.zip
2         	02/19/14  	Rel20.0_XsiCTISchema_449493.zip
3         	11/21/13  	Rel20.0_XsiCTISchema_438273.zip
1         	11/20/13  	Rel_20.0_1.606_OCISchema_NS_HTML.zip
1         	11/20/13  	Rel_20.0_1.606_OCISchema_ALL.zip
1         	11/20/13  	Rel_20.0_1.606_OCISchema_AS_HTML.zip
3         	11/04/13  	Rel20.0_XsiCTISchema_433939.zip
